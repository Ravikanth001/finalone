"use strict";

const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const database = new sqlite3.Database("./my.db");
const app = express();
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const SECRET_KEY = "secretkey23456";
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

router.post('/register', (req, res) => {
    const first_name = req.body.first_name;
    const last_name = req.body.last_name;
    const Age = req.body.Age;
    const Gender = req.body.Gender;
    const Address = req.body.Address;
    const phone_num=req.body.phone_num
    const email = req.body.email;
    const password = bcrypt.hashSync(req.body.password);
    createUser([first_name,last_name,Age,Gender,Address,phone_num, email, password], (err) => {
    if (err) return res.status(500).send("Server error!");
    findUserByEmail(email, (err, user) => {
    if (err) return res.status(500).send('Server error!');
    const expiresIn = 24 * 60 * 60;
    const accessToken = jwt.sign({ id: user.id }, SECRET_KEY, {
    expiresIn: expiresIn
    });
    res.status(200).send({
    "user": user, "accessToken": accessToken, "expires_in": expiresIn
    });
    });
    });
    });
  

router.post('/login', (req, res) => {
        const email = req.body.email;
        const password = req.body.password;
        findUserByEmail(email, (err, user) => {
        if (err) return res.status(500).send('Server error!');
        if (!user) return res.status(404).send('User not found!');
        const result = bcrypt.compareSync(password, user.password);
        if (!result) return res.status(401).send('Password not valid!');
        const expiresIn = 24 * 60 * 60;
        const accessToken = jwt.sign({ id: user.id }, SECRET_KEY, {
        expiresIn: expiresIn
        });
        res.status(200).send({ "user": user,
        "accessToken": accessToken,
        "expires_in": expiresIn });
        });
        });
            router.delete("/users/:id", (req, res) => {
            database.run(
                'DELETE FROM users WHERE id = ?',
                req.params.id,
                function (err, result) {
                    if (err){
                        res.status(400).json({"error": res.message})
                        return;
                    }
                    res.json({"message":"deleted", changes: this.changes})
            });
        })

        router.delete("/visittable/:id", (req, res) => {
            database.run(
                'DELETE FROM visittable WHERE id = ?',
                req.params.id,
                function (err, result) {
                    if (err){
                        res.status(400).json({"error": res.message})
                        return;
                    }
                    res.json({"message":"deleted", changes: this.changes})
            });
        })




router.get('/users',(req,res)=>{
            var sql="select * from users"
            var params=[]
            database.all(sql,params,(err,rows)=>{
                    if(err){
                        res.status(400).json({"error":err.message});
                        return;
                    }
                    res.json({
                        "message":"success",
                        "data":rows
                    })
            })

        });

router.get('/visittable',(req,res)=>{
            var sql="select * from visittable"
            var params=[]
            database.all(sql,params,(err,rows)=>{
                    if(err){
                        res.status(400).json({"error":err.message});
                        return;
                    }
                    res.json({
                        "message":"success",
                        "data":rows
                    })
            })

        });


router.get('/users/:id',(req,res)=>{
            var sql="select * from users where id=?"
            var params=[req.params.id]
            database.get(sql,params,(err,rows)=>{
                    if(err){
                        res.status(400).json({"error":err.message});
                        return;
                    }
                    res.json({
                        "message":"success",
                        "data":rows
                    })
            })

        });

 router.get('/visittable/:id',(req,res)=>{
            var sql="select * from visittable where id=?"
            var params=[req.params.id]
            database.get(sql,params,(err,rows)=>{
                    if(err){
                        res.status(400).json({"error":err.message});
                        return;
                    }
                    res.json({
                        "message":"success",
                        "data":rows
                    })
            })

        });


router.patch("/users/:id", (req, res) => {
            var data = {
                first_name: req.body.first_name,
                last_name:req.body.last_name,
                Age:req.body.Age,
                Gender:req.body.Gender,
                Address:req.body.Address,
                phone_num:req.body.phone_num,
                email: req.body.email,
                password : req.body.password ? md5(req.body.password) : null
            }
            database.run(
                `UPDATE users set 
                   first_name = COALESCE(?,first_name), 
                   last_name = COALESCE(?,last_name), 
                   Age = COALESCE(?,Age), 

                   Gender = COALESCE(?,Gender), 

                   Address  = COALESCE(?,Address), 
                   phone_num = COALESCE(?,phone_num), 

                   email = COALESCE(?,email), 
                   password = COALESCE(?,password) 
                   WHERE id = ?`,
                [data.first_name,data.last_name,data.Age,data.Gender,data.Address,data.phone_num,data.email, data.password, req.params.id],
                function (err, result) {
                    if (err){
                        res.status(400).json({"error": res.message})
                        return;
                    }
                    res.json({
                        message: "success",
                        data: data,
                        changes: this.changes
                    })
            });
        })
      

    app.use(router);
const port = process.env.PORT || 3005;
const server = app.listen(port, () => {
console.log('Server listening at http://localhost:' +
port);
});

router.get('/', (req, res) => {
    res.status(200).send('This is an authenticationserver');
    });

    const createUsersTable = () => {
        const sqlQuery =
        `
        CREATE TABLE IF NOT EXISTS users (
        id integer PRIMARY KEY AUTOINCREMENT,
        first_name text,
        last_name text,
        Age text,
        Gender text,
        Address text,
        phone_num numeric,
        email text UNIQUE,
        password text)`;
        return database.run(sqlQuery);
        }
    const createUsersTable1 = () => {
            const sqlQuery =
            `
            CREATE TABLE IF NOT EXISTS visittable (
            id integer PRIMARY KEY AUTOINCREMENT,
            cust_name text,
            contact_person text,
            intrest_product text,
            visit_subject text,
            description text,
            visit_datetime date,
            is_diabled text,
            is_deleted text,
            emp_id integer
            FOREIGN KEY(emp_id) REFERENCES users(id))`;
            return database.run(sqlQuery);
            }


            router.post('/visittable', (req, res) => {
                const cust_name = req.body.cust_name;
                const contact_person = req.body.contact_person;
                const intrest_product = req.body.intrest_product;
                const visit_subject = req.body.visit_subject;
                const description = req.body.description;
                const visit_datetime=req.body.visit_datetime 
                const is_disabled = req.body.is_disabled;
                const is_deleted =req.body.is_deleted;
                const emp_id =req.body.emp_id;
                createUser([cust_name,contact_person,intrest_product,visit_subject,description,visit_datetime, is_disabled, is_deleted,emp_id], (err) => {
                if (err) return res.status(500).send("Server error!");
                findUserByemp_id(emp_id, (err, visittable) => {
                if (err) return res.status(500).send('Server error!');
                const expiresIn = 24 * 60 * 60;
                const accessToken = jwt.sign({ id: visittable.id }, SECRET_KEY, {
                expiresIn: expiresIn
                });
                res.status(200).send({
                "visittable": visittable, "accessToken": accessToken, "expires_in": expiresIn
                });
                });
                });
                });


const findUserByEmail = (email, cb) => {
            return database.get(`SELECT * FROM users WHERE email = ?`, [email], (err, row)=> {
            cb(err, row)
            });
            }



const createUser = (user, cb) => {
            return database.run('INSERT INTO users (first_name,last_name,Age,Gender,Address,phone_num,email, password) VALUES(?,?,?,?,?,?,?,?)', user, (err) => {
            cb(err)
            });
            }
            // let’s create the users table by calling the createUsersTable()
            createUsersTable();