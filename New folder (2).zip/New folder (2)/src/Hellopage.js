import React from "react";
//import { Link } from 'react-router-dom'
function Hello() {
    if(!localStorage.getItem('mytoken')){
         window.location = '/login'
        }


  
    return (
    <>
   <div >
    <h4>Hello</h4>
    
    
    </div>
    </>
    
    );
    }
    

export default Hello;