import { useState } from "react";
import axios from 'axios';
function Registration(){
return (<>
<MyForm />
</>);
}

function MyForm() {
    const mystyle={
        maxWidth: "500px",
        margin: "auto",
        background: "white",
        padding: "10px",
        borderStyle:"solid",
        backgroundColor:"orange",
     
    }
    //initialize useState with emtpy {} and it will return 2 values,
    //The current state, and a function that updates the state.
    const [inputs, setInputs] = useState({});
    function handleChange(event){
    //during change of every element.
    //save name in 'name' and its value in value
    const name = event.target.name;
    const value = event.target.value;
    // setInputs is the function that updates the state.
    setInputs(values => ({...values, [name]: value}))
    }
    function handleSubmit(event) {
        //to prevent default html form submit behaviour
        event.preventDefault();
        //alert the current state
        console.log(inputs);
        axios
        .post('/register',inputs)
        .then(response => {
            console.log('Promise was fulfilled')
            console.log(response)
            window.location='/login'
        })

        }
        return (
            <div >
            <form onSubmit={handleSubmit}>
            <table style={mystyle}>
            <tr>
            <th>
            
            
                <label>Firstname:
                     <input type="text" name="first_name"
                        value={inputs.first_name || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
            
            
            <tr>
            <th>
            <label>Lastname:
            <th>
                     <input type="text" name="last_name"
                        value={inputs.last_name || ""}
                        onChange={handleChange}
                        required
                    />
                    </th>
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>Age:
                     <input type="text" name="Age"
                        value={inputs.Age || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>Gender:
                     <input type="text" name="Gender"
                        value={inputs.Gender || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>Address:
                     <input type="text" name="Address"
                        value={inputs.Address || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>Phonenum:
                <input type="tel" name="phone_num"
                        value={inputs.phone_num || ""}
                        onChange={handleChange}
                        required
                        />
                    
                </label>
                </th>
                </tr>
          
                 
             <tr>
             <th>
                <label>email:
        
                        <input type="email" name="email"
                        value={inputs.email || ""}
                        onChange={handleChange}
                        required
                        />
                   
                </label>
                 </th>
                 </tr>
                 <tr>
             <th>
                <label>password:
        
                        <input type="password" name="password"
                        value={inputs.password || ""}
                        onChange={handleChange}
                        required
                        />
                   
                </label>
                 </th>
                 </tr>
                
                 <tr>
                 <th>
                <input type="submit" />
                </th>
                 </tr>
                </table>

            </form> 
            </div>
        )
}
export default Registration;