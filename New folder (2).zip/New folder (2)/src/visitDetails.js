import { useState, useEffect } from "react";
import {useParams} from "react-router-dom"
import axios from "axios";
//import { useNavigate } from 'react-router-dom';



function VisitDetails(){
    const st={
        //display:"inline",
       // align:"center",
        // marginTop:"0%",
        //marginLeft:"50%",
        borderStyle : "solid",
        backgroundColor:"orange"
        
    }
//initialize the use case to empty

const[visit, setVisit] = useState({})
const {id} = useParams();

useEffect(()=> {
    axios
    .get(`/visittable/${id}`)
    .then(response => {
    console.log('promise was fullfilled')
    console.log(response)
    setVisit(response.data)
    })
    },[])

    return (<>
        <div style={st}>
        <h2>cust_nameDetails of {visit.cust_name}</h2>
        <h2>contact_personirst  : {visit.contact_person}</h2>
        <h2>intrest_product : {visit.intrest_product}</h2>
        <h2>visit_subject : {visit.visit_subject}</h2>
        <h2>description : {visit.description}</h2>
        <h2>emp_id : {visit.emp_id}</h2>
        <a href="/stafflist">Back to Staff List</a>
        <br/><br/>
       
        <button type="button"
                onClick={()=>DeleteVisit(visit.id)}>Delete</button>
        </div>
        </>);
}
function DeleteVisit(id){
    console.log('delete1 promise was fullfilled')
    axios
    .delete(`/visittable/${id}`)
    .then(response => {
    console.log('delete promise was fullfilled')
    console.log(response)
    })
    window.location = '/visitlist'
    }
    

export default VisitDetails;