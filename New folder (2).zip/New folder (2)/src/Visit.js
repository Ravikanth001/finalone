import React from "react";
import { Link } from 'react-router-dom'
function Visit(props) {
    console.log(props)


  
    return (
    <>
   <div >
    <h4>{props.details.cust_name}</h4>
    <Link to={`/visitdetails/${props.details.id}`}> view details</Link>
    
    </div>
    </>
    
    );
    }
    

export default Visit;