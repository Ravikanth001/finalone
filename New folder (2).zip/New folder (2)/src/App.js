import {BrowserRouter as Router,Routes, Route, Link} from "react-router-dom"
import React from "react";

import Registration from "./Registration";
import Login from "./Login";
//import Hello from "./Hellopage";
import VisitDetails from "./visitDetails";
import Visit from "./Visit";
import VisitList from "./visitlist";
import Visittable from "./Visittable";
import './App.css';
const styling={
  marginTop:"0%",
  display:"inline",
  backgroundColor:"blue"
}
const styling1={
  marginTop:"0%",
  
  
}
function App() {
  return (

<Router>
  <div style={styling}>
    <header>
      <nav>
        <ul>
  
              <li>
                    <Link to="Registration">Registration</Link>
              </li>
                <li>
                    {localStorage.getItem('mytoken') &&<div> <Link to="visitlist">visitlist</Link></div>}
              </li>
              <li>
                {localStorage.getItem('mytoken') &&<div> <Link to="visittable">Visit Reg</Link></div>}
              </li>
              <li>
                       {!localStorage.getItem('mytoken') && <div><Link to="/login">Login</Link></div>}
              </li>
               <li>
                        {localStorage.getItem('mytoken') && <div><Link onClick={ () =>window.location= '/login'} to="/login">Logout</Link></div>}
              </li>
             

          </ul>
          <hr/>

      </nav>
    </header>
</div>
<div style={styling1}>
<Routes>
  <Route path="/login" element={<Login />}/>
  <Route path="/Registration" element ={<Registration />}/>
  <Route path="visit" element ={<Visit/>}/>
  <Route path="/visitdetails"element={<VisitDetails/>}/>
  <Route path="visitlist" element ={<VisitList/>}/>
  <Route path="/visittable" element={<Visittable/>}/>
</Routes>
</div>







  </Router>
  );
}

export default App;
