import { useState } from "react";
import axios from 'axios';
function Visittable(){

    if(!localStorage.getItem('mytoken')){
        window.location = '/login'
       }
return (<>
<MyForm />
</>);
}

function MyForm() {
    const mystyle={
        maxWidth: "500px",
        margin: "auto",
        background: "white",
        padding: "10px",
        borderStyle:"solid",
        backgroundColor:"orange",
     
    }
    //initialize useState with emtpy {} and it will return 2 values,
    //The current state, and a function that updates the state.
    const [inputs, setInputs] = useState({});
    function handleChange(event){
   
    const name = event.target.name;
    const value = event.target.value;

    setInputs(values => ({...values, [name]: value}))
    }
    function handleSubmit(event) {
        //to prevent default html form submit behaviour
        event.preventDefault();
        //alert the current state
        console.log(inputs);
        axios
        .post('/visittable',inputs)
        .then(response => {
            console.log('Promise was fulfilled')
            console.log(response)
            window.location='/visitlist'
        })

        }
        return (

            <div >
            <form onSubmit={handleSubmit}>
            <table style={mystyle}>
            <tr>
            <th>
            
            
                <label>cust_name:
                     <input type="text" name="cust_name"
                        value={inputs.cust_name || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
            
            
            <tr>
            <th>
            <label>contact_person:
            <th>
                     <input type="text" name="contact_person"
                        value={inputs.contact_person || ""}
                        onChange={handleChange}
                        required
                    />
                    </th>
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>intrest_product:
                     <input type="text" name="intrest_product"
                        value={inputs.intrest_product || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>visit_subject:
                     <input type="text" name="visit_subject"
                        value={inputs.visit_subject || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>description:
                     <input type="text" name="description"
                        value={inputs.description || ""}
                        onChange={handleChange}
                        required
                    />
                </label>
                </th>
                </tr>
                <tr>
            <th>
            
            
                <label>visit_datetime:
                <input type="date" name="visit_datetime"
                        value={inputs.visit_datetime || ""}
                        onChange={handleChange}
                        required
                        />
                    
                </label>
                </th>
                </tr>
          
                 
             <tr>
             <th>
                <label>is_diabled:
                <input type="radio" name="is_disabled" value={inputs.is_diabled || ""}onChange={handleChange} required/> True 
                        <br/>  
                <input type="radio" name="is_disabled" value={inputs.is_diabled || ""} onChange={handleChange} required/> False
                        <br/>   
                    
                   
                </label>
                 </th>
                 </tr>
                 <tr>
             <th>
                <label>is_deleted:
        
                <input type="radio" name="is_deleted" value={inputs.is_deleted || ""}onChange={handleChange} required/> True 
                        <br/>  
                <input type="radio" name="is_deleted" value={inputs.is_deleted || ""} onChange={handleChange} required/> False
                        <br/>   
                    
                   
                </label>
                 </th>
                 </tr>

                 <tr>
             <th>
                <label>emp_id:
        
                        <input type="text" name="emp_id"
                        value={inputs.emp_id || ""}
                        onChange={handleChange}
                        required
                        />
                   
                </label>
                 </th>
                 </tr>

                
                
                 <tr>
                 <th>
                <input type="submit" />
                </th>
                 </tr>
                </table>

            </form> 
            </div>
        )
}
export default Visittable;